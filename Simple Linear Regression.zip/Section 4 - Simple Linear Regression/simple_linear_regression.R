#simple_linear_regression

#importing the dataset
dataset = read.csv('Salary_Data.csv')
#dataset = dataset[,2:3]

#Splitting the dataset into training set and test set
#install.packages('caTools')
library(caTools)
set.seed(123) #similar to random_state in python
split = sample.split(dataset$Salary,SplitRatio = 2/3)
#here splitratio is training ratio while in python we have set test ratio
training_set = subset(dataset,split == TRUE)
test_set = subset(dataset,split == FALSE)

#Feature Scaling
#training_set[,2:3] = scale(training_set[,2:3])
#test_set[,2:3] = scale(test_set[,2:3])
#here we have to specify columns because column 1 and column 2 have text as data before so we have to exclude it

#Fitting simple linear regression to the training set
regressor = lm(formula = Salary ~ YearsExperience,
                data = training_set)

#predicting the test set results
y_pred = predict(regressor,
                 newdata = test_set)

#Visualising the training set result
#install.packages('ggplot2')
library(ggplot2)
ggplot() +
  geom_point(aes(x = training_set$YearsExperience, y = training_set$Salary),
             colour = 'red') +
  geom_line(aes(x = training_set$YearsExperience,
                y = predict(regressor, newdata = training_set)),colour = 'blue') +
  ggtitle('Salary vs Experience(training set)') +
  xlab('Years of Experience') +
  ylab('Salary')

#Visualising the test set result
#install.packages('ggplot2')
library(ggplot2)
ggplot() +
  geom_point(aes(x = test_set$YearsExperience, y = test_set$Salary),
             colour = 'red') +
  geom_line(aes(x = training_set$YearsExperience,
                y = predict(regressor, newdata = training_set)),colour = 'blue') +
  ggtitle('Salary vs Experience(test set)') +
  xlab('Years of Experience') +
  ylab('Salary')
  






